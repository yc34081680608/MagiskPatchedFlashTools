# MagiskPatchedFlashTools  
Magisk修补刷入工具  

# 更新日志  
### v1.0  
首个版本:更新Magisk版本,修补boot,刷入boot  
### v1.1
更新脚本为EXE程序  
### v1.2
更新内置Magisk版本为Alpha_c97d1044_25102  

