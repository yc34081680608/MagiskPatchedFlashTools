# MagiskPatchedFlashTools

Magisk 修补刷入工具

## 更新日志

### v1.8

修复 VBMeta 刷入问题

### v1.7

更新内置 Magisk 版本为 Alpha_ed37ddd5_25205

### v1.6

更新内置 Magisk 版本为 Alpha_44643ad7_25205

### v1.5

添加解锁 BootLoader  
添加关闭 AVB 校验  
更新内置 Magisk 版本为 Alpha_555a54ec_25203

### v1.4

添加程序版本信息  
更新内置 Magisk 版本为 Alpha_c5c608f0_25202

### v1.3

更新内置 Magisk 版本为 Alpha_1735a713_25201

### v1.2

更新内置 Magisk 版本为 Alpha_c97d1044_25102

### v1.1

更新脚本为 EXE 程序

### v1.0

首个版本:更新 Magisk 版本,修补 boot,刷入 boot
